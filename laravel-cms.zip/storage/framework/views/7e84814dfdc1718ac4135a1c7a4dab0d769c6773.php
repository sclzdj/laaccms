
<?php $__env->startSection('heads'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('templates/default/css/index.css')); ?>">
    <link href="https://cdn.bootcss.com/Swiper/4.3.0/css/swiper.min.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/Swiper/4.3.0/js/swiper.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-header">
                        置顶文章
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php 
            $expression=['is_top'=>1];
            $db=\Modules\Article\Entities\Content::where('id','>','0');
            if(isset($expression['category_ids'])){
                $db->whereIn('category_id',$expression['category_ids']);
            }
            if(isset($expression['is_top'])){
                $db->where('is_top',$expression['is_top']);
            }
            if(isset($expression['is_hot'])){
                $db->orderBy('click','DESC');
            }
            if(isset($expression['limit'])){
                $db->limit($expression['limit']);
            }else{
                $db->limit(10);
            }
            $contents=$db->get();
            foreach ($contents as $key=>$item):
                $item['url']='/article/home/content/'.$item['id'];
            ?>
                            <a href="<?php echo e($item['url']); ?>">
                                <li class="list-group-item"><?php echo e($item['title']); ?></li>
                            </a>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                            <div class="swiper-container">
                    <div class="swiper-wrapper">
                        
                    </div>
                    <!-- 如果需要分页器 -->
                    <div class="swiper-pagination"></div>
                    <!-- 如果需要导航按钮 -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                    <!-- 如果需要滚动条 -->
                    <!-- <div class="swiper-scrollbar"></div> -->
                </div>
                <!--导航等组件可以放在container之外-->
                <style>
                    .swiper-container {
                        width: 100%;
                        height: 300px;
                    }
                    .swiper-container img{
                        width: 100%;
                        height: 300px;
                    }
                </style>
                <script>
                    new Swiper('.swiper-container', {
                        loop: true,
                        autoplay:true,
                        // 如果需要分页器
                        pagination: {
                            el: '.swiper-pagination',
                        },
                        // 如果需要前进后退按钮
                        navigation: {
                            nextEl: '.swiper-button-next',
                            prevEl: '.swiper-button-prev',
                        },
                        // 如果需要滚动条
                        /*scrollbar: {
                            el: '.swiper-scrollbar',
                        },*/
                    });
                </script>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-header">
                        热门文章
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php 
            $expression=['is_hot'=>1];
            $db=\Modules\Article\Entities\Content::where('id','>','0');
            if(isset($expression['category_ids'])){
                $db->whereIn('category_id',$expression['category_ids']);
            }
            if(isset($expression['is_top'])){
                $db->where('is_top',$expression['is_top']);
            }
            if(isset($expression['is_hot'])){
                $db->orderBy('click','DESC');
            }
            if(isset($expression['limit'])){
                $db->limit($expression['limit']);
            }else{
                $db->limit(10);
            }
            $contents=$db->get();
            foreach ($contents as $key=>$item):
                $item['url']='/article/home/content/'.$item['id'];
            ?>
                            <a href="<?php echo e($item['url']); ?>">
                                <li class="list-group-item"><?php echo e($item['title']); ?></li>
                            </a>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-3">
        <div class="row">
            <?php 
            $categorys = \Modules\Article\Entities\Category::where('pid','0')->get()->toArray(); 
            $channels  = \houdunwang\arr\Arr::channelList($categorys, 0, "&nbsp;", 'id'); 
            foreach ($channels as $key=>$item):
                $item['url']='/article/home/lists/'.$item['id']; 
            ?>
            <div class="col-sm-6 mb-3">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($item['name']); ?>

                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php 
            $expression=['category_ids'=>[$item['id']]];
            $db=\Modules\Article\Entities\Content::where('id','>','0');
            if(isset($expression['category_ids'])){
                $db->whereIn('category_id',$expression['category_ids']);
            }
            if(isset($expression['is_top'])){
                $db->where('is_top',$expression['is_top']);
            }
            if(isset($expression['is_hot'])){
                $db->orderBy('click','DESC');
            }
            if(isset($expression['limit'])){
                $db->limit($expression['limit']);
            }else{
                $db->limit(10);
            }
            $contents=$db->get();
            foreach ($contents as $key=>$item):
                $item['url']='/article/home/content/'.$item['id'];
            ?>
                            <a href="<?php echo e($item['url']); ?>">
                                <li class="list-group-item"><?php echo e($item['title']); ?></li>
                            </a>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>