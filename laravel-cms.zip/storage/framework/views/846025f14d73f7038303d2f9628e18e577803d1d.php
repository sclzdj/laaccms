
<?php $__env->startSection('heads'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('templates/default/css/index.css')); ?>">
    <link href="https://cdn.bootcss.com/Swiper/4.3.0/css/swiper.min.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/Swiper/4.3.0/js/swiper.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts._message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-9">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($content['title']); ?>

                    </div>
                    <div class="card-body">
                        <?php echo $content['content']; ?>

                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-header">
                        热门文章
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php 
            $expression=['is_hot'=>1];
            $db=\Modules\Article\Entities\Content::where('id','>','0');
            if(isset($expression['category_ids'])){
                $db->whereIn('category_id',$expression['category_ids']);
            }
            if(isset($expression['is_top'])){
                $db->where('is_top',$expression['is_top']);
            }
            if(isset($expression['is_hot'])){
                $db->orderBy('click','DESC');
            }
            if(isset($expression['limit'])){
                $db->limit($expression['limit']);
            }else{
                $db->limit(10);
            }
            $contents=$db->get();
            foreach ($contents as $key=>$item):
                $item['url']='/article/home/content/'.$item['id'];
            ?>
                            <a href="<?php echo e($item['url']); ?>">
                                <li class="list-group-item"><?php echo e($item['title']); ?></li>
                            </a>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-3">
        <div class="row">
            <div class=" col-sm-9">
                <div class="card">
                    <div class="card-header">
                        评论列表
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php $__currentLoopData = $content->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">
                                    <div class="row">
                                        <div class="col-sm-9">
                                            <?php echo e($comment['content']); ?>

                                        </div>
                                        <div class="col-sm-3">
                                            <small class="text-secondary"><?php echo e($comment->user->name); ?>

                                                &nbsp;/&nbsp;<?php echo e($comment->created_at->diffForHumans()); ?></small>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="card-footer text-muted">
                        <?php if(auth()->guard()->guest()): ?>
                            <div class="text-center">
                                <a href="/login" class="btn btn-primary">请登录后发表评论</a>
                            </div>
                        <?php else: ?>
                            <form action="/article/comment" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="content_id" value="<?php echo e($content['id']); ?>">
                                <div class="form-group">
                                    <textarea class="form-control" name="content" placeholder="请输入评论"
                                              rows="5"></textarea>
                                </div>
                                <div class="form-group">
                                    <button class="form-control" type="submit">提交</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>