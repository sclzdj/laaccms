<?php if(count($errors)>0): ?>
    <div role="alert" class="alert alert-contrast alert-warning alert-dismissible">
    <button type="button" data-dismiss="alert" aria-label="Close" class="close">
        <span aria-hidden="true" class="mdi mdi-close"></span>
    </button>
    <div class="icon"><span class="mdi mdi-alert-triangle"></span></div>
        <div class="message">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<?php endif; ?>