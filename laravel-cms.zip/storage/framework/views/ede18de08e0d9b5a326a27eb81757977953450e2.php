<div id="be-navbar-collapse" class="navbar-collapse collapse">
    <ul class="navbar-nav">
        <li class="nav-item"><a href="/admin" class="nav-link">系统模块</a></li>
        <li class="nav-item dropdown">
            <a href="#" data-toggle="dropdown" role="button" aria-expanded="false"
               class="nav-link dropdown-toggle">
                扩展模块 <span class="mdi mdi-caret-down"></span>
            </a>
            <div role="menu" class="dropdown-menu">
                <?php $__currentLoopData = \HDModule::getModulesLists(['Admin']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/<?php echo e(strtolower($module['name'])); ?>" class="dropdown-item"
                       onclick="sessionStorage.removeItem('current_menu_id');"><?php echo e(strtolower($module['title'])); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
    </ul>
</div>