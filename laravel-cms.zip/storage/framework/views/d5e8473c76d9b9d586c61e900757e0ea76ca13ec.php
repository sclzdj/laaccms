<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.tabls'); ?>
        <?php $__env->slot('title'); ?>
            文章列表
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('nav'); ?>
            <li class="nav-item">
                <a class="nav-link active" href="/article/content">文章列表</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/article/content/create">添加文章</a>
            </li>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('body'); ?>
            <p class="card-text">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">标题</th>
                    <th scope="col">栏目</th>
                    <th scope="col">作者</th>
                    <th scope="col">缩略图</th>
                    <th scope="col">置顶</th>
                    <th scope="col">查看次数</th>
                    <th scope="col">创建时间</th>
                    <th scope="col">操作</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($item['id']); ?></th>
                        <td><?php echo e($item['title']); ?></td>
                        <td><?php echo e($item->category->name); ?></td>
                        <td><?php echo e($item['author']); ?></td>
                        <td>
                            <?php if($item['thumb']!==''): ?>
                                <a href="<?php echo e($item['thumb']); ?>" target="_blank"><img src="<?php echo e($item['thumb']); ?>" class="img-thumbnail"
                                     style="max-width: 50px;max-height: 50px;padding:0;"></a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item['is_top']?'是':'否'); ?></td>
                        <td><?php echo e($item['click']); ?></td>
                        <td><?php echo e($item['created_at']); ?></td>
                        <td>
                            <div class="btn-group btn-space">
                                <a href="/article/content/<?php echo e($item['id']); ?>/edit" class="btn btn-secondary">编辑</a>
                                <button type="button" class="btn btn-secondary" onclick="contentDestroy(this)">删除
                                </button>
                                <form action="/article/content/<?php echo e($item['id']); ?>}" method="post">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </p>
            <p class="card-text">
                <?php echo $data->links(); ?>

            </p>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function contentDestroy(fn) {
            if (confirm('确定删除栏目？')) {
                $(fn).next('form').trigger('submit');
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>