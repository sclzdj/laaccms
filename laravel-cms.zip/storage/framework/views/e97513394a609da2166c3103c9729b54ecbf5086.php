<?php $__env->startSection('content'); ?>
    <div class="card" id="app">
        <div class="card-header">评论管理</div>
        <div class="tab-container">
            <ul role="tablist" class="nav nav-tabs">
                <li class="nav-item"><a href="/article/comment" class="nav-link active">评论列表</a></li>
            </ul>
            <div class="card card-contrast card-border-color-success">
                <div class="card-body">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>编号</th>
                            <th>用户</th>
                            <th>文章</th>
                            <th>内容</th>
                            <th>创建时间</th>
                            <th>修改时间</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo $d['id']; ?></td>
                                <td><?php echo $d->user->name; ?></td>
                                <td><?php echo \Modules\Article\Entities\Content::where('id',$d['content_id'])->first()->title; ?></td>
                                <td><?php echo $d['content']; ?></td>
                                <td><?php echo $d['created_at']; ?></td>
                                <td><?php echo $d['updated_at']; ?></td>
                                <td>
                                    <button type="button" class="btn btn-secondary btn-danger" onclick="del(<?php echo e($d['id']); ?>,this)">删除</button>
                                    <form action="/article/comment/<?php echo e($d['id']); ?>" hidden method="post">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="float-right">
        <?php echo $data->links(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function del(id, el) {
            if (confirm('确定删除吗？')) {
                $(el).next('form').trigger('submit')
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>