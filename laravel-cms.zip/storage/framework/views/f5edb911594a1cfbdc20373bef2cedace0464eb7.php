<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs">
            <?php echo e($nav); ?>

        </ul>
    </div>
    <div class="card-header">
        <?php echo e($title); ?>

    </div>
    <div class="card-body">
        <?php echo e($body); ?>

    </div>
</div>