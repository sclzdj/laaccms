<?php $__currentLoopData = ['success','warning','danger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session()->has($t)): ?>
        <div role="alert" class="alert alert-<?php echo e($t); ?> alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="mdi mdi-close"></span></button>
            <div class="icon"><span class="mdi mdi-check"></span></div>
            <div class="message">
                <strong><?php echo e(session()->get($t)); ?></strong>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(session('status')): ?>
    <div role="alert" class="alert alert-success alert-dismissible">
        <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="mdi mdi-close"></span></button>
        <div class="icon"><span class="mdi mdi-check"></span></div>
        <div class="message">
            <?php echo e(session('status')); ?>

        </div>
    </div>
<?php endif; ?>