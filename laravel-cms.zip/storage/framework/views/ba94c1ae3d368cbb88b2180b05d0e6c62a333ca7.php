
<?php $__env->startSection('heads'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('templates/default/css/index.css')); ?>">
    <link href="https://cdn.bootcss.com/Swiper/4.3.0/css/swiper.min.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/Swiper/4.3.0/js/swiper.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="card">
                    <div class="card-header">
                        文章列表
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/article/home/content/<?php echo e($content['id']); ?>">
                                <li class="list-group-item"><?php echo e($content['title']); ?></li>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="footer">
                        <?php echo e($contents->links()); ?>

                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-header">
                        热门文章
                    </div>
                    <div class="card-block">
                        <ul class="list-group">
                            <?php 
            $expression=['is_hot'=>1];
            $db=\Modules\Article\Entities\Content::where('id','>','0');
            if(isset($expression['category_ids'])){
                $db->whereIn('category_id',$expression['category_ids']);
            }
            if(isset($expression['is_top'])){
                $db->where('is_top',$expression['is_top']);
            }
            if(isset($expression['is_hot'])){
                $db->orderBy('click','DESC');
            }
            if(isset($expression['limit'])){
                $db->limit($expression['limit']);
            }else{
                $db->limit(10);
            }
            $contents=$db->get();
            foreach ($contents as $key=>$item):
                $item['url']='/article/home/content/'.$item['id'];
            ?>
                            <a href="<?php echo e($item['url']); ?>">
                                <li class="list-group-item"><?php echo e($item['title']); ?></li>
                            </a>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>