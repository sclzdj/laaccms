<div class="left-sidebar-scroll">
    <div class="left-sidebar-content">
        <ul class="sidebar-elements">
            
            <?php $__currentLoopData = \HDModule::getMenuByModule(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(\HDModule::hadPermission($modules['permission'],'admin')): ?>
                    <li class="parent" id="menu_left_<?php echo e($modules['title']); ?>">
                        <a href="#"><i class="icon <?php echo e($modules['icon']); ?>"></i><span><?php echo e($modules['title']); ?></span></a>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $modules['menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\HDModule::hadPermission($item['permission'],'admin')): ?>
                                    <li>
                                        <a href="<?php echo e($item['url']); ?>" pjax><?php echo e($item['title']); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <li class="divider">技术支持</li>
            <li class="parent"><a href="#"><i class="icon mdi mdi-view-web"></i><span>支持</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="layouts-primary-header.html">视频教程</a>
                    </li>
                    <li>
                        <a href="layouts-success-header.html">访问官网</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>

