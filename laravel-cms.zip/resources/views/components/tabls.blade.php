<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs">
            {{$nav}}
        </ul>
    </div>
    <div class="card-header">
        {{$title}}
    </div>
    <div class="card-body">
        {{$body}}
    </div>
</div>