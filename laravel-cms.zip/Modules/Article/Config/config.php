<?php

return [
    'name' => '文章模块'
];
