<?php return array (
  'name' => '系统模块',
  'defaultTemplateName' => 'default',
);