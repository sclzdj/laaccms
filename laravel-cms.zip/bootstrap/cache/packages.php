<?php return array (
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'houdunwang/laravel-autocreate' => 
  array (
    'providers' => 
    array (
      0 => '\\Houdunwang\\AutoCreate\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'HDModule' => '\\Houdunwang\\AutoCreate\\Factory',
    ),
  ),
  'houdunwang/laravel-module' => 
  array (
    'providers' => 
    array (
      0 => '\\Houdunwang\\Module\\LaravelServiceProvider',
    ),
    'aliases' => 
    array (
      'HDModule' => '\\Houdunwang\\Module\\Factory',
    ),
  ),
  'houdunwang/laravel-upload' => 
  array (
    'providers' => 
    array (
      0 => 'Houdunwang\\LaravelUpload\\ServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'laravel/horizon' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Horizon\\HorizonServiceProvider',
    ),
    'aliases' => 
    array (
      'Horizon' => 'Laravel\\Horizon\\Horizon',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
);